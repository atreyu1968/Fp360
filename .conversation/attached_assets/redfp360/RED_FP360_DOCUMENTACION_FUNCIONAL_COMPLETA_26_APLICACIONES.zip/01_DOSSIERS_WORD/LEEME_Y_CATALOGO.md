# RED FP360 · DOSSIER DE LAS 26 APLICACIONES

Versión 1.0 · 18 de octubre de 2026 · Documento de trabajo para curso 2027–2028

**Contenido**: 26 documentos DOCX individuales, guía maestra transversal, catálogo JSON y carpeta de 26 maquetas PNG 1920 × 1080. Cada dossier describe procesos, datos, pantallas/pestañas, reglas de negocio, conexiones, IA, evaluación, roles y criterios de aceptación.

**Carácter**: diseño prospectivo; las maquetas no representan software ya implementado. Todas las empresas, identificadores, cuentas y documentos de los ejemplos son simulados. Tributación indirecta canaria (IGIC).

## Catálogo

- 01. **Dirección y cuadro de mando** — 6 vistas descritas. Archivo: `01_RED_FP360_Direccion_y_cuadro_de_mando.docx`.
- 02. **CRM y contactos** — 6 vistas descritas. Archivo: `02_RED_FP360_CRM_y_contactos.docx`.
- 03. **Ventas y facturación** — 7 vistas descritas. Archivo: `03_RED_FP360_Ventas_y_facturacion.docx`.
- 04. **Compras y aprovisionamiento** — 6 vistas descritas. Archivo: `04_RED_FP360_Compras_y_aprovisionamiento.docx`.
- 05. **Productos y servicios** — 6 vistas descritas. Archivo: `05_RED_FP360_Productos_y_servicios.docx`.
- 06. **Almacén e inventario** — 7 vistas descritas. Archivo: `06_RED_FP360_Almacen_e_inventario.docx`.
- 07. **Logística y distribución** — 6 vistas descritas. Archivo: `07_RED_FP360_Logistica_y_distribucion.docx`.
- 08. **Contabilidad** — 7 vistas descritas. Archivo: `08_RED_FP360_Contabilidad.docx`.
- 09. **Tesorería** — 7 vistas descritas. Archivo: `09_RED_FP360_Tesoreria.docx`.
- 10. **Recursos humanos** — 7 vistas descritas. Archivo: `10_RED_FP360_Recursos_humanos.docx`.
- 11. **Nóminas** — 7 vistas descritas. Archivo: `11_RED_FP360_Nominas.docx`.
- 12. **Atención al cliente** — 6 vistas descritas. Archivo: `12_RED_FP360_Atencion_al_cliente.docx`.
- 13. **Proyectos y servicios** — 7 vistas descritas. Archivo: `13_RED_FP360_Proyectos_y_servicios.docx`.
- 14. **Gestión documental** — 6 vistas descritas. Archivo: `14_RED_FP360_Gestion_documental.docx`.
- 15. **Mercado FP360** — 7 vistas descritas. Archivo: `15_RED_FP360_Mercado_FP360.docx`.
- 16. **Banco FP360** — 7 vistas descritas. Archivo: `16_RED_FP360_Banco_FP360.docx`.
- 17. **Hacienda FP360** — 7 vistas descritas. Archivo: `17_RED_FP360_Hacienda_FP360.docx`.
- 18. **Seguridad Social FP360** — 7 vistas descritas. Archivo: `18_RED_FP360_Seguridad_Social_FP360.docx`.
- 19. **Empleo FP360** — 6 vistas descritas. Archivo: `19_RED_FP360_Empleo_FP360.docx`.
- 20. **Centro de comunicaciones** — 7 vistas descritas. Archivo: `20_RED_FP360_Centro_de_comunicaciones.docx`.
- 21. **FP360 SIM — Dirección inteligente de simulaciones** — 8 vistas descritas. Archivo: `21_RED_FP360_FP360_SIM_Direccion_inteligente_de_simulaciones.docx`.
- 22. **Portafolio profesional** — 6 vistas descritas. Archivo: `22_RED_FP360_Portafolio_profesional.docx`.
- 23. **Evaluación docente** — 7 vistas descritas. Archivo: `23_RED_FP360_Evaluacion_docente.docx`.
- 24. **Mentoría empresarial** — 6 vistas descritas. Archivo: `24_RED_FP360_Mentoria_empresarial.docx`.
- 25. **Coordinación intercentros** — 7 vistas descritas. Archivo: `25_RED_FP360_Coordinacion_intercentros.docx`.
- 26. **Administración del sistema** — 8 vistas descritas. Archivo: `26_RED_FP360_Administracion_del_sistema.docx`.

## Uso recomendado para Replit

1. Cargar primero `00_GUIA_MAESTRA...docx` y la imagen correspondiente al módulo.
2. Implementar el módulo con las pantallas enumeradas, servicios de backend y validaciones.
3. Añadir pruebas de seguridad multitenant y concurrencia entre empresas.
4. Ejecutar casos extremos, obtener evidencia docente y actualizar manual y repositorio.
5. No alterar la identidad visual aprobada ni inventar integraciones completadas.

## Advertencia

Los modelos administrativos son didácticos. Antes de utilizarlos para formación en normativa concreta se deben comprobar y versionar los parámetros fiscales, laborales y contables del curso correspondiente.
