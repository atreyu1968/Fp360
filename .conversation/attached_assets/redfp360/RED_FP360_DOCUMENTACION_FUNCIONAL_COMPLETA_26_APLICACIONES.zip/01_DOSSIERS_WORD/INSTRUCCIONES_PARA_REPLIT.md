# RED FP360 — Instrucciones de desarrollo modular

1. Leer primero `00_GUIA_MAESTRA_IDENTIDAD_ARQUITECTURA_Y_CATALOGO.docx` y `SISTEMA_DE_DISENO_VISUAL.json`.
2. Para cada módulo, cargar su `DOCX`, su `PNG` de referencia y su ficha en `ESPECIFICACIONES_EDITABLES_PARA_REPLIT.json`.
3. Las capturas son referencias visuales, NO imágenes para incrustar como pantallas funcionales. Construir la UI real con HTML/CSS/componentes y conexión a backend.
4. Crear los modelos de datos con identificador de centro, empresa y campaña; comprobar permisos en servidor.
5. Implementar las pestañas definidas en el dossier; cubrir la tabla de validaciones y las pruebas AC-01 a AC-10.
6. Mantener aislamiento multitenant, trazabilidad, datos ficticios y simulación de banco, Hacienda, empleo y Seguridad Social.
7. Integrar la IA como generadora de instrucciones/casos, y un motor determinista para consecuencias económicas.
8. Actualizar README, pruebas y contratos API al terminar cada módulo.

Los 26 módulos deben integrarse en la misma plataforma. Los documentos son especificaciones prospectivas y no certifican que el ERP exista todavía.
